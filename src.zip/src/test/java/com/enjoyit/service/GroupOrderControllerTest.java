package com.enjoyit.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * 針對 UC-04：主揪團購訂單管理 進行單元測試
 * 測試方法名稱與 Operation Contract 對應
 */
@SpringBootTest
@AutoConfigureMockMvc
public class GroupOrderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    /**
     * 測試 CO-07: publishGroupOrder
     * 驗證發布團購後是否回傳正確的點餐連結
     */
    @Test
    public void testPublishGroupOrder() throws Exception {
        String jsonRequest = "{\"orderInfo\": \"下午茶團購\", \"announcement\": \"請在 11 點前點完\"}";

        mockMvc.perform(post("/api/group-orders/publish")
                        .contentType(MediaType.APPLICATION_BITSTREAM.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isOk())
                .andExpect(content().string("displayOrderLink"));
    }

    /**
     * 測試 CO-08: setOrderDeadline
     * 驗證設定截止時間後狀態是否更新
     */
    @Test
    public void testSetOrderDeadline() throws Exception {
        // 先確保有一個進行中的團購
        testPublishGroupOrder();

        // 設定一個未來的時間
        String deadlineJson = "{\"deadline\": \"2026-12-31T23:59:59\"}";

        mockMvc.perform(put("/api/group-orders/deadline")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(deadlineJson))
                .andExpect(status().isOk());
    }

    /**
     * 測試 CO-09: inputAdminPassword
     * 驗證管理者密碼輸入邏輯
     */
    @Test
    public void testInputAdminPassword() throws Exception {
        testPublishGroupOrder();

        // 這裡需要根據你 GroupOrder 生成的預設密碼邏輯來測試，先以模擬正確情況為主
        String passwordJson = "{\"password\": \"正確的密碼\"}";

        // 備註：此處若密碼不對會回傳 401，符合操作合約 Postcondition
        mockMvc.perform(post("/api/group-orders/validate-admin")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(passwordJson))
                .andExpect(status().isOk());
    }

    /**
     * 測試 CO-10: downloadOrderSummary
     * 驗證在「已結單」狀態下是否能產出報表
     */
    @Test
    public void testDownloadOrderSummary_WhenNotClosed() throws Exception {
        testPublishGroupOrder();

        // 團購尚未截止（Precondition 不符），應回傳錯誤
        mockMvc.perform(get("/api/group-orders/summary"))
                .andExpect(status().isBadRequest());
    }
}